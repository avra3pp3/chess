// ---------- Правила шахмат ----------
// Доска: массив из 64 клеток, индекс = ряд*8 + колонка, ряд 0 — верхний (8-я горизонталь).
// Фигура — строка вида 'wK' (цвет + тип): K король, Q ферзь, R ладья, B слон, N конь, P пешка.

const ROOK = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const BISHOP = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
const KING = ROOK.concat(BISHOP);
const KNIGHT = [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]];

const inBoard = (r, c) => r >= 0 && r < 8 && c >= 0 && c < 8;
const other = (color) => (color === 'w' ? 'b' : 'w');

function newState() {
  const board = Array(64).fill(null);
  const back = 'RNBQKBNR';
  for (let c = 0; c < 8; c++) {
    board[c] = 'b' + back[c];
    board[8 + c] = 'bP';
    board[48 + c] = 'wP';
    board[56 + c] = 'w' + back[c];
  }
  return { board, turn: 'w', castle: { wK: 1, wQ: 1, bK: 1, bQ: 1 }, ep: -1 };
}

// Атакована ли клетка sq фигурами цвета by
function attacked(b, sq, by) {
  const r = sq >> 3, c = sq & 7;
  const at = (rr, cc) => (inBoard(rr, cc) ? b[rr * 8 + cc] : null);
  const pr = by === 'w' ? r + 1 : r - 1;
  if (at(pr, c - 1) === by + 'P' || at(pr, c + 1) === by + 'P') return true;
  for (const [dr, dc] of KNIGHT) if (at(r + dr, c + dc) === by + 'N') return true;
  for (const [dr, dc] of KING) if (at(r + dr, c + dc) === by + 'K') return true;
  for (const [dr, dc] of KING) {
    let rr = r + dr, cc = c + dc;
    while (inBoard(rr, cc)) {
      const p = b[rr * 8 + cc];
      if (p) {
        if (p[0] === by) {
          const t = p[1];
          const straight = dr === 0 || dc === 0;
          if (t === 'Q' || (t === 'R' && straight) || (t === 'B' && !straight)) return true;
        }
        break;
      }
      rr += dr; cc += dc;
    }
  }
  return false;
}

// Ходы фигуры без проверки, остаётся ли король под шахом
function pseudoMoves(s, from) {
  const b = s.board, p = b[from], col = p[0], t = p[1];
  const r = from >> 3, c = from & 7, opp = other(col), out = [];
  const add = (to, extra) => out.push({ from, to, ...extra });

  if (t === 'P') {
    const d = col === 'w' ? -1 : 1, startRow = col === 'w' ? 6 : 1, lastRow = col === 'w' ? 0 : 7;
    const push = (to) => {
      if (to >> 3 === lastRow) for (const promo of 'QRBN') add(to, { promo });
      else add(to);
    };
    if (inBoard(r + d, c) && !b[(r + d) * 8 + c]) {
      push((r + d) * 8 + c);
      if (r === startRow && !b[(r + 2 * d) * 8 + c]) add((r + 2 * d) * 8 + c, { dbl: true });
    }
    for (const dc of [-1, 1]) {
      if (!inBoard(r + d, c + dc)) continue;
      const to = (r + d) * 8 + c + dc;
      if (b[to] && b[to][0] === opp) push(to);
      else if (to === s.ep) add(to, { ep: true });
    }
  } else if (t === 'N' || t === 'K') {
    for (const [dr, dc] of t === 'N' ? KNIGHT : KING) {
      if (!inBoard(r + dr, c + dc)) continue;
      const to = (r + dr) * 8 + c + dc;
      if (!b[to] || b[to][0] === opp) add(to);
    }
    const home = col === 'w' ? 60 : 4;
    if (t === 'K' && from === home && !attacked(b, home, opp)) {
      if (s.castle[col + 'K'] && !b[home + 1] && !b[home + 2] && b[home + 3] === col + 'R' &&
          !attacked(b, home + 1, opp)) add(home + 2, { castle: 'K' });
      if (s.castle[col + 'Q'] && !b[home - 1] && !b[home - 2] && !b[home - 3] && b[home - 4] === col + 'R' &&
          !attacked(b, home - 1, opp)) add(home - 2, { castle: 'Q' });
    }
  } else {
    const dirs = t === 'R' ? ROOK : t === 'B' ? BISHOP : KING;
    for (const [dr, dc] of dirs) {
      let rr = r + dr, cc = c + dc;
      while (inBoard(rr, cc)) {
        const to = rr * 8 + cc;
        if (!b[to]) add(to);
        else { if (b[to][0] === opp) add(to); break; }
        rr += dr; cc += dc;
      }
    }
  }
  return out;
}

// Возвращает новое состояние после хода (исходное не меняется)
function applyMove(s, m) {
  const b = s.board.slice(), p = b[m.from], col = p[0];
  const n = { board: b, turn: other(col), castle: { ...s.castle }, ep: -1 };
  b[m.to] = m.promo ? col + m.promo : p;
  b[m.from] = null;
  if (m.ep) b[m.to + (col === 'w' ? 8 : -8)] = null;
  if (m.castle === 'K') { b[m.from + 1] = b[m.from + 3]; b[m.from + 3] = null; }
  if (m.castle === 'Q') { b[m.from - 1] = b[m.from - 4]; b[m.from - 4] = null; }
  if (m.dbl) n.ep = (m.from + m.to) / 2;
  if (p[1] === 'K') n.castle[col + 'K'] = n.castle[col + 'Q'] = 0;
  for (const [sq, key] of [[63, 'wK'], [56, 'wQ'], [7, 'bK'], [0, 'bQ']]) {
    if (m.from === sq || m.to === sq) n.castle[key] = 0;
  }
  return n;
}

function inCheck(s, col = s.turn) {
  return attacked(s.board, s.board.indexOf(col + 'K'), other(col));
}

// Все легальные ходы игрока, чей сейчас ход
function legalMoves(s) {
  const out = [];
  for (let i = 0; i < 64; i++) {
    if (!s.board[i] || s.board[i][0] !== s.turn) continue;
    for (const m of pseudoMoves(s, i)) {
      if (!inCheck(applyMove(s, m), s.turn)) out.push(m);
    }
  }
  return out;
}

// ---------- Интерфейс ----------
if (typeof document !== 'undefined') {
  const pieceSvg = (t) => '<svg viewBox="0 0 100 100" aria-hidden="true"><use href="#p-' + t + '"/></svg>';
  const NAME = { w: 'белых', b: 'чёрных' };
  const WINNER = { w: 'белые', b: 'чёрные' };

  const boardEl = document.getElementById('board');
  const statusEl = document.getElementById('status');
  const seatEl = document.getElementById('seat');
  const promoEl = document.getElementById('promo');
  const promoChoices = document.getElementById('promo-choices');

  let state, moves, selected, over, message, winner;
  let history = [], net = null;
  let rated = false, replaying = false, me = null, dbApi = null, userApi = null;

  // Контейнер для конфетти при победе
  const confettiEl = document.createElement('div');
  confettiEl.id = 'confetti';
  document.body.appendChild(confettiEl);

  function launchConfetti() {
    const colors = ['#f0c65a', '#f3ebdd', '#6fae7b', '#d9694f'];
    const count = window.matchMedia('(max-width: 600px)').matches ? 36 : 60; // на телефонах меньше, чтобы не тормозило
    for (let i = 0; i < count; i++) {
      const bit = document.createElement('i');
      bit.style.left = Math.random() * 100 + '%';
      bit.style.background = colors[i % colors.length];
      bit.style.animationDuration = 2.5 + Math.random() * 2.5 + 's';
      bit.style.animationDelay = Math.random() * 1.2 + 's';
      confettiEl.appendChild(bit);
    }
  }

  function resetBoard() {
    history = [];
    rated = false;
    // На одном устройстве случайно решаем, кто из игроков берёт белых
    const first = Math.random() < 0.5 ? 1 : 2;
    seatEl.textContent = 'Белыми играет Игрок ' + first + ', чёрными — Игрок ' + (3 - first);
    state = newState();
    moves = legalMoves(state);
    selected = null;
    over = false;
    winner = null;
    confettiEl.innerHTML = '';
    promoEl.classList.add('hidden');
    render();
  }

  function render() {
    const targets = selected === null ? [] : moves.filter((m) => m.from === selected).map((m) => m.to);
    const checkSq = !over && inCheck(state) ? state.board.indexOf(state.turn + 'K') : -1;
    boardEl.innerHTML = '';
    const flip = net && net.color === 'b';
    for (let d = 0; d < 64; d++) {
      const i = flip ? 63 - d : d;
      const sq = document.createElement('div');
      sq.className = 'sq ' + (((i >> 3) + (i & 7)) % 2 === 0 ? 'light' : 'dark');
      if (i === selected) sq.classList.add('selected');
      if (i === checkSq) sq.classList.add('check');
      if (targets.includes(i)) {
        const isCapture = state.board[i] || (state.board[selected][1] === 'P' && i === state.ep);
        sq.classList.add(isCapture ? 'capture' : 'move');
      }
      const p = state.board[i];
      if (p) {
        const span = document.createElement('span');
        span.className = 'piece ' + p[0];
        span.innerHTML = pieceSvg(p[1]);
        if (over && p[1] === 'K') {
          span.classList.add(!winner ? 'king-draw' : winner === p[0] ? 'king-win' : 'king-lose');
        }
        sq.appendChild(span);
      }
      sq.addEventListener('click', () => onSquare(i));
      boardEl.appendChild(sq);
    }
    statusEl.className = over ? 'over' : '';
    statusEl.textContent = statusText();
    resignBtn.classList.toggle('hidden', !(net && net.opp && !over));
  }

  function statusText() {
    if (over) return message;
    if (net && !net.opp) {
      return 'Комната ' + net.code + ': ' + (net.host ? 'ждём соперника…' : 'подключаемся…');
    }
    let t = (inCheck(state) ? 'Шах! ' : '') + 'Ход ' + NAME[state.turn];
    if (net) t += state.turn === net.color ? ' — ваш ход' : ' — ждите соперника';
    return t;
  }

  function onSquare(i) {
    if (over || !promoEl.classList.contains('hidden')) return;
    if (net && (!net.opp || state.turn !== net.color)) return;
    if (selected !== null) {
      const ms = moves.filter((m) => m.from === selected && m.to === i);
      if (ms.length) {
        if (ms[0].promo) return askPromotion(ms);
        return play(ms[0]);
      }
    }
    const p = state.board[i];
    selected = p && p[0] === state.turn ? i : null;
    render();
  }

  function askPromotion(ms) {
    promoChoices.innerHTML = '';
    for (const t of 'QRBN') {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.innerHTML = pieceSvg(t);
      btn.className = 'pc' + state.turn;
      btn.addEventListener('click', () => {
        promoEl.classList.add('hidden');
        play(ms.find((m) => m.promo === t));
      });
      promoChoices.appendChild(btn);
    }
    promoEl.classList.remove('hidden');
  }

  function play(m, remote) {
    const mover = state.turn;
    history.push({ from: m.from, to: m.to, promo: m.promo || null });
    if (net && !replaying && history.length === 1) snapshotRatings();
    if (net && !remote) {
      net.room.emit('move', { n: history.length, from: m.from, to: m.to, promo: m.promo || null });
    }
    state = applyMove(state, m);
    moves = legalMoves(state);
    selected = null;
    if (moves.length === 0) {
      over = true;
      winner = inCheck(state) ? mover : null;
      message = inCheck(state)
        ? 'Мат! Победили ' + WINNER[mover] + '.'
        : 'Пат! Ничья.';
      if (net && !replaying) {
        const d = rateGame(winner === null ? 0.5 : winner === net.color ? 1 : 0);
        if (d !== null) message += ' Рейтинг: ' + fmtDelta(d) + '.';
      }
    }
    render();
    if (winner) launchConfetti();
  }

  // ---------- Игра по сети (комнаты по коду) ----------
  // Экраны: лобби, меню комнаты, игра
  const screens = {
    lobby: document.getElementById('lobby'),
    'room-menu': document.getElementById('room-menu'),
    game: document.getElementById('game'),
  };
  function show(name) {
    for (const [id, el] of Object.entries(screens)) el.classList.toggle('hidden', id !== name);
    if (name === 'lobby') refreshProfile();
  }
  const menuNote = document.getElementById('menu-note');
  const menuMsg = (text) => { menuNote.textContent = text || ''; };
  const infoEl = document.getElementById('net-info');
  const leaveBtn = document.getElementById('leave-room');
  const codeInput = document.getElementById('room-code');
  const resignBtn = document.getElementById('resign');
  let retry = null, resignArm = null;

  // Конец партии из-за сдачи одного из игроков
  function finish(winnerColor, text) {
    over = true;
    winner = winnerColor;
    message = text;
    if (net && !replaying) {
      const d = rateGame(winnerColor === net.color ? 1 : 0);
      if (d !== null) message += ' Рейтинг: ' + fmtDelta(d) + '.';
    }
    selected = null;
    promoEl.classList.add('hidden');
    render();
    if (!net || winnerColor === net.color) launchConfetti();
  }

  function netNote(text) {
    infoEl.textContent = text;
    infoEl.classList.toggle('hidden', !text);
  }
  function netUi() {
    seatEl.classList.toggle('hidden', !!net);
    netNote(net ? 'Комната ' + net.code + (net.color ? ' · вы играете ' + (net.color === 'w' ? 'белыми' : 'чёрными') : '') : '');
  }
  function sendSync(peer) {
    net.room.emit('sync', { to: peer, moves: history.map((h) => [h.from, h.to, h.promo]), you: net.color === 'w' ? 'b' : 'w' });
  }
  function replay(list) {
    resetBoard();
    replaying = true;
    for (const [f, t, p] of list) {
      const m = moves.find((x) => x.from === f && x.to === t && (x.promo || null) === p);
      if (!m) break;
      play(m, true);
    }
    replaying = false;
    if (over) rated = true; // уже закончившаяся партия повторно не считается
    else if (history.length) snapshotRatings();
  }

  // ---------- Подключение к комнатам через Supabase Realtime ----------
  const SUPABASE_URL = 'https://lzfpwalesmehaesefrri.supabase.co';
  const SUPABASE_KEY = 'sb_publishable_agnTgczb0HOwYl2KEuPQHQ_tc35diCk'; // публичный ключ, его можно показывать
  let sb = null;
  try { sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY); } catch (e) { sb = null; }

  // Возвращает объект комнаты: emit / on / onPeers / presence / peers / leave
  function joinRoom(name) {
    return new Promise((resolve, reject) => {
      const myKey = Math.random().toString(36).slice(2) + Date.now().toString(36);
      const channel = sb.channel('chess-' + name, { config: { broadcast: { self: true }, presence: { key: myKey } } });
      const handlers = {}, peerCbs = [];
      channel.on('broadcast', { event: 'm' }, ({ payload }) => {
        const msg = { data: payload.d, peer: payload.from, sameTab: payload.from === myKey, by: null };
        (handlers[payload.t] || []).slice().forEach((fn) => fn(msg));
      });
      channel.on('presence', { event: 'leave' }, ({ key }) => {
        peerCbs.slice().forEach((fn) => fn({ left: [{ peer: key }] }));
      });
      const room = {
        emit: (topic, data) => channel.send({ type: 'broadcast', event: 'm', payload: { t: topic, d: data, from: myKey } }),
        on(topic, fn) {
          (handlers[topic] = handlers[topic] || []).push(fn);
          return () => { handlers[topic] = handlers[topic].filter((f) => f !== fn); };
        },
        onPeers(fn) { peerCbs.push(fn); return () => { const k = peerCbs.indexOf(fn); if (k >= 0) peerCbs.splice(k, 1); }; },
        presence: (obj) => channel.track(obj),
        peers: () => Object.entries(channel.presenceState()).map(([k, list]) => ({
          peer: k, isMe: k === myKey, presence: list[list.length - 1],
        })),
        leave: () => sb.removeChannel(channel),
      };
      channel.subscribe((status) => {
        if (status === 'SUBSCRIBED') { channel.track({}); resolve(room); }
        else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') reject(new Error(status));
      });
    });
  }

  async function enterRoom(code, host) {
    let room = null;
    try {
      room = sb ? await joinRoom(code.toLowerCase()) : null;
    } catch (e) { room = null; }
    if (!room) {
      menuMsg('Не удалось подключиться к серверу. Проверьте интернет и попробуйте ещё раз.');
      return;
    }
    resetBoard();
    const n = (net = { room, code, host, color: host ? (Math.random() < 0.5 ? 'w' : 'b') : null, opp: null, me: null, off: [] });
    const fromOpp = (msg) => !msg.sameTab && msg.peer === n.opp;
    n.off.push(room.on('hello', (msg) => {
      if (msg.sameTab) { n.me = msg.peer; return; }
      if (!n.host) return; // отвечает только хост
      if (n.opp && n.opp !== msg.peer) { room.emit('busy', { to: msg.peer }); return; } // третьему вход закрыт
      n.opp = msg.peer;
      n.oppId = msg.by;
      sendSync(msg.peer);
      render();
    }));
    n.off.push(room.on('need', (msg) => { if (fromOpp(msg)) sendSync(msg.peer); }));
    n.off.push(room.on('sync', (msg) => {
      const d = msg.data;
      if (msg.sameTab || !d || d.to !== n.me || (n.host && msg.peer !== n.opp)) return;
      n.opp = msg.peer;
      n.oppId = msg.by;
      if (d.you) n.color = d.you; // цвет гостя задаёт хост
      replay(d.moves || []);
      netUi();
    }));
    n.off.push(room.on('move', (msg) => {
      const d = msg.data;
      if (!fromOpp(msg) || !d || over || state.turn === n.color) return;
      if (d.n !== history.length + 1) { if (d.n > history.length + 1) room.emit('need', {}); return; }
      // ход соперника проверяется по правилам, как и свой
      const m = moves.find((x) => x.from === d.from && x.to === d.to && (x.promo || null) === (d.promo || null));
      if (m) play(m, true); else room.emit('need', {});
    }));
    n.off.push(room.on('busy', (msg) => {
      const d = msg.data;
      if (msg.sameTab || n.host || !d || d.to !== n.me) return;
      leaveRoom('В этой комнате уже играют двое.');
    }));
    n.off.push(room.on('resign', (msg) => {
      if (!fromOpp(msg) || over) return;
      finish(n.color, 'Соперник сдался. Победили ' + WINNER[n.color] + '.');
    }));
    n.off.push(room.on('reset', (msg) => {
      if (!fromOpp(msg)) return;
      if (msg.data && msg.data.opp) n.color = msg.data.opp; // цвета разыграны заново
      resetBoard();
      netUi();
    }));
    n.off.push(room.onPeers((c) => {
      if (n.opp && c.left.some((p) => p.peer === n.opp)) {
        // старая комната закрывается, старый код больше не работает
        leaveRoom(n.host ? false : 'Хост закрыл комнату. Создайте новую или введите другой код.');
        if (n.host) {
          // хост сразу открывает новую комнату с новым кодом
          enterRoom(makeCode(), true).then(() => {
            if (net) netNote('Соперник вышел. Новый код комнаты: ' + net.code + ' · вы играете белыми');
          });
        }
      }
    }));
    room.emit('hello', {});
    if (host) {
      room.presence({ host: true }); // по этой метке гость сразу видит, что комната существует
    } else {
      setTimeout(() => {
        const hostHere = room.peers().some((p) => !p.isMe && p.presence && p.presence.host);
        if (net === n && !n.opp && !hostHere) {
          leaveRoom('Неверный код.');
        }
      }, 1200);
    }
    if (!host) {
      // Входим только в существующую комнату: если хост не ответил за ~5 секунд, выходим
      let tries = 0;
      retry = setInterval(() => {
        if (net !== n || n.opp) return clearInterval(retry);
        if (++tries > 5) {
          clearInterval(retry);
          return leaveRoom('Неверный код.');
        }
        room.emit('hello', {});
      }, 1000);
    }
    menuMsg('');
    show('game');
    netUi();
    render();
  }

  function leaveRoom(msg) {
    if (!net) return;
    clearInterval(retry);
    net.off.forEach((off) => off());
    net.room.leave();
    net = null;
    resetBoard();
    netUi();
    if (msg === false) return; // тихий выход (смена кода хостом)
    menuMsg(msg);
    show(msg ? 'room-menu' : 'lobby');
  }

  function makeCode() {
    const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let s = '';
    for (let i = 0; i < 4; i++) s += abc[Math.floor(Math.random() * abc.length)];
    return s;
  }

  // Рейтинг пока не используется (аккаунтов нет), оставлены пустые заглушки
  function refreshProfile() {}
  function snapshotRatings() {}
  function rateGame() { return null; }
  function fmtDelta() { return ''; }

  // Лобби
  const modeRoom = document.getElementById('mode-room');
  if (!sb) {
    modeRoom.disabled = true;
    document.getElementById('lobby-note').classList.remove('hidden');
  }
  document.getElementById('mode-local').addEventListener('click', () => {
    resetBoard();
    netUi();
    show('game');
  });
  modeRoom.addEventListener('click', () => { menuMsg(''); codeInput.value = ''; show('room-menu'); });
  document.getElementById('room-back').addEventListener('click', () => show('lobby'));
  document.getElementById('create-room').addEventListener('click', () => enterRoom(makeCode(), true));
  // Как только введены 4 символа, сразу входим в комнату
  codeInput.addEventListener('input', () => {
    codeInput.value = codeInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (codeInput.value.length === 4) {
      const code = codeInput.value;
      codeInput.value = '';
      enterRoom(code, false);
    }
  });
  leaveBtn.addEventListener('click', () => { if (net) leaveRoom(); else show('lobby'); });
  // Сдаться можно в любой момент (не только в свой ход); нужно нажать дважды
  resignBtn.addEventListener('click', () => {
    if (!net || !net.opp || over) return;
    if (!resignArm) {
      resignBtn.textContent = 'Точно сдаться?';
      resignArm = setTimeout(() => { resignArm = null; resignBtn.textContent = 'Сдаться'; }, 3000);
      return;
    }
    clearTimeout(resignArm);
    resignArm = null;
    resignBtn.textContent = 'Сдаться';
    net.room.emit('resign', {});
    const win = other(net.color);
    finish(win, 'Вы сдались. Победили ' + WINNER[win] + '.');
  });

  document.getElementById('new-game').addEventListener('click', () => {
    if (net) {
      net.color = Math.random() < 0.5 ? 'w' : 'b'; // новый жребий цвета
      if (net.opp) net.room.emit('reset', { opp: net.color === 'w' ? 'b' : 'w' });
    }
    resetBoard();
    if (net) netUi();
  });
  resetBoard();
}
